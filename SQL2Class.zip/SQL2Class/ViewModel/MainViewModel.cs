using System.Collections.Generic;
using System.Data.Common;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SQL2Class
{
    public class MainViewModel : ViewModelBase
    {
        private Window recentW;
        public Window RecentW
        {
            get { return recentW; }
            set
            {
                base.RaisePropertyChangingEvent("RecentW");
                recentW = value;
                base.RaisePropertyChangedEvent("RecentW");
            }
        }

        private string userName;
        public string UserName
        {
            get { return userName; }
            set
            {
                base.RaisePropertyChangingEvent("UserName");
                userName = value;
                base.RaisePropertyChangedEvent("UserName");
            }
        }

        private string serverName;
        public string ServerName
        {
            get { return serverName; }
            set
            {
                base.RaisePropertyChangingEvent("ServerName");
                serverName = value;
                base.RaisePropertyChangedEvent("ServerName");
            }
        }

        private string databaseName;
        public string DatabaseName
        {
            get { return databaseName; }
            set
            {
                base.RaisePropertyChangingEvent("DatabaseName");
                databaseName = value;
                base.RaisePropertyChangedEvent("DatabaseName");
            }
        }

        private List<DataSource> listDS = DataSource.GetAll();
        public List<DataSource> ListDS
        {
            get { return listDS; }
            set
            {
                base.RaisePropertyChangingEvent("ListDS");
                listDS = value;
                base.RaisePropertyChangedEvent("ListDS");
            }
        }

        private DataSource selectedDS;
        public DataSource SelectedDS
        {
            get { return selectedDS; }
            set
            {
                base.RaisePropertyChangingEvent("SelectedDS");
                selectedDS = value;
                base.RaisePropertyChangedEvent("SelectedDS");
            }
        }

        private bool fieldEnable;
        public bool FieldEnable
        {
            get { return fieldEnable; }
            set
            {
                base.RaisePropertyChangingEvent("FieldEnable");
                fieldEnable = value;
                base.RaisePropertyChangedEvent("FieldEnable");
            }
        }

        public ICommand Next { get; set; }

        public MainViewModel(Window win)
        {
            Next = new RelayCommand<object>(MainNextExecute, MainNextCanExecute);
            SelectedDS = listDS[0];

            recentW = win;
        }

        public void ComboBoxChange()
        {
            if (selectedDS.Id == 0 || selectedDS.Id == 2)
            {
                FieldEnable = false;
            }
            else
            {
                FieldEnable = true;
            }
        }

        public void MainNextExecute(object passwordBox)
        {
            string ConnectionString = "";
            string password = ((PasswordBox)passwordBox).Password;
            DbProviderFactories.RegisterFactory("System.Data.SqlClient", System.Data.SqlClient.SqlClientFactory.Instance);
            DbProviderFactories.RegisterFactory("Npgsql", Npgsql.NpgsqlFactory.Instance);
            DbProviderFactories.RegisterFactory("Oracle", Oracle.ManagedDataAccess.Client.OracleClientFactory.Instance);
            DbProviderFactories.RegisterFactory("System.Data.OleDb", System.Data.OleDb.OleDbFactory.Instance);

            DbProviderFactory factory = DbProviderFactories.GetFactory(selectedDS.Factory);
            DbConnection connection = factory.CreateConnection();

            if (selectedDS.Id == 0)
            {
                ConnectionString = @"provider = microsoft.jet.oledb.4.0;data source = "
                    + serverName + ";Jet OLEDB:Database Password=" + password;
            }
            else if (selectedDS.Id == 1)
            {
                ConnectionString = @"Data Source=" + serverName + ";Initial Catalog="
                    + databaseName + ";User ID=" + userName +
                    ";Password=" + password;
            }
            else if (selectedDS.Id == 2)
            {
                ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;data source = "
                    + serverName + ";Jet OLEDB:Database Password=" + password;
            }
            else if (selectedDS.Id == 3)
            {
                ConnectionString = "Data Source=(localdb)\\v11.0;AttachDbFilename=\""
                    + serverName + "\";Integrated Security=True";
                /*ConnectionString = @"Data Source=(localdb)\\v11.0;AttachDbFilename="
                    + serverName + ";User ID=" + userName +
                    ";Password=" + password;*/
            }
            /*else if (selectedDS.Id == 4)
            {
                ConnectionString = "Data Source=" + serverName + ";Password=" + password;
            }*/
            else if (selectedDS.Id == 4)
            {
                ConnectionString = "Server=" + serverName + ";Port=5432;Database=" + databaseName
                    + ";User Id=" + userName + ";Password=" + password + ";";
            }
            else if (selectedDS.Id == 5)
            {
                ConnectionString = "User Id=" + userName + ";Password=" + password
                    + ";Data Source=" + serverName + "/" + databaseName + ";";
            }

            try
            {
                connection.ConnectionString = ConnectionString;
                connection.Open();

                AllTableWindow win = new AllTableWindow(ConnectionString, selectedDS.Factory);
                win.Show();
                recentW.Close();
            }
            catch
            {
                MessageBox.Show("Connection false");
            }
        }

        public bool MainNextCanExecute(object passwordBox)
        {
            bool result = false;
            string password = passwordBox != null ? ((PasswordBox)passwordBox).Password : "";

            if (fieldEnable)
            {
                if (password.Length > 0 && userName.Length > 0
                    && databaseName != null && serverName.Length > 0)
                    if (databaseName.Length > 0)
                        result = true;
            }
            else
            {
                if (password.Length > 0 && serverName.Length > 0)
                    result = true;
            }

            return result;
        }

    }
}