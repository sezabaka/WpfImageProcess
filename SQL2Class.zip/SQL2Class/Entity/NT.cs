using System;
using System.ComponentModel;

namespace SQL2Class
{
    public class NT : INotifyPropertyChanged
    {
        private string fieldName;
        public string FieldName
        {
            get { return fieldName; }
            set
            {
                fieldName = value;
                OnPropertyChanged("FieldName");
            }
        }

        private Type fieldType;
        public Type FieldType
        {
            get { return fieldType; }
            set
            {
                fieldType = value;
                OnPropertyChanged("FieldType");
            }
        }

        public NT(string fieldName, Type fieldType)
        {
            FieldName = fieldName;
            FieldType = fieldType;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string s)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(s));
            }
        }
    }
}