using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.Common;
using System.Text;
using System.Windows;
using System.Windows.Input;

namespace SQL2Class
{
    public class AllTableViewModel : ViewModelBase
    {
        #region Properties
        private Window recentW;
        public Window RecentW
        {
            get { return recentW; }
            set
            {
                base.RaisePropertyChangingEvent("RecentW");
                recentW = value;
                base.RaisePropertyChangedEvent("RecentW");
            }
        }

        private string spaceName;
        public string SpaceName
        {
            get { return spaceName; }
            set
            {
                base.RaisePropertyChangingEvent("SpaceName");
                spaceName = value;
                base.RaisePropertyChangedEvent("SpaceName");
            }
        }

        private string baseName;
        public string BaseName
        {
            get { return baseName; }
            set
            {
                base.RaisePropertyChangingEvent("BaseName");
                baseName = value;
                base.RaisePropertyChangedEvent("BaseName");
            }
        }

        private ObservableCollection<string> tableNames;
        public ObservableCollection<string> TableNames
        {
            get { return tableNames; }
            set
            {
                base.RaisePropertyChangingEvent("TableNames");
                tableNames = value;
                base.RaisePropertyChangedEvent("TableNames");
            }
        }

        private string tableSelected;
        public string TableSelected
        {
            get { return tableSelected; }
            set
            {
                base.RaisePropertyChangingEvent("TableSelected");
                tableSelected = value;
                base.RaisePropertyChangedEvent("TableSelected");
            }
        }

        private GetData selectedData = GetData.Field;
        public GetData SelectedData
        {
            get { return selectedData; }
            set
            {
                base.RaisePropertyChangingEvent("SelectedData");
                selectedData = value;
                base.RaisePropertyChangedEvent("SelectedData");
            }
        }

        private WpfData selectedWpf = WpfData.Class;
        public WpfData SelectedWpf
        {
            get { return selectedWpf; }
            set
            {
                base.RaisePropertyChangingEvent("SelectedWpf");
                selectedWpf = value;
                base.RaisePropertyChangedEvent("SelectedWpf");
            }
        }

        private AngularData selectedAngular = AngularData.Interface;
        public AngularData SelectedAngular
        {
            get { return selectedAngular; }
            set
            {
                base.RaisePropertyChangingEvent("SelectedAngular");
                selectedAngular = value;
                base.RaisePropertyChangedEvent("SelectedAngular");
            }
        }

        private string connectionString;
        private string factoryName;

        public ICommand Get { get; set; }
        public ICommand WpfGenerator { get; set; }
        public ICommand AngularGenerator { get; set; }
        public ICommand Save { get; set; }
        public ICommand ExecNonQuery { get; set; }

        #endregion Properties

        public AllTableViewModel(Window win, string connectionString1, string fact)
        {
            Get = new RelayCommand(AllTableGetExecute, AllTableGetCanExecute);
            WpfGenerator = new RelayCommand(WpfGeneratorExecute, WpfGeneratorCanExecute);
            AngularGenerator = new RelayCommand(AngularGeneratorExecute, AngularGeneratorCanExecute);
            Save = new RelayCommand(AllTableSaveExecute, AllTableSaveCanExecute);
            ExecNonQuery = new RelayCommand(AllTableExecNonQueryExecute);

            recentW = win;
            connectionString = connectionString1;
            factoryName = fact;
            TableNames = getTableName(connectionString, factoryName);
        }

        public ObservableCollection<string> getTableName(string connectionString, string fact)
        {
            ObservableCollection<string> temp = new ObservableCollection<string>();
            DbProviderFactory factory = DbProviderFactories.GetFactory(fact);
            DataTable usertable = null;
            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                string[] restrictions = new string[4];


                connection.Open();

                if (fact == "System.Data.SqlClient" || fact == "System.Data.SqlServerCe.4.0"
                    || fact == "Npgsql" || fact == "Oracle")
                {
                    usertable = connection.GetSchema("Tables");
                }
                else if (fact == "System.Data.OleDb")
                {
                    restrictions[3] = "Table";
                    usertable = connection.GetSchema("Tables", restrictions);
                }

                connection.Close();
            }
            for (int i = 0; i < usertable.Rows.Count; i++)
            {
                if (fact == "Oracle")
                {
                    if (usertable.Rows[i][0].ToString() == "QV_ACT")
                        temp.Add(usertable.Rows[i][1].ToString());
                }
                else
                {
                    temp.Add(usertable.Rows[i][2].ToString());
                }
            }

            return temp;
        }//End getTableName

        public void AllTableGetExecute()
        {
            if (selectedData == GetData.Field)
            {
                List<NT> nts = new List<NT>();
                nts = GenData.GetField(tableSelected, connectionString, factoryName);

                var win = new DataWindow();
                win.SetDatagrid(nts);
                win.ShowDialog();
            }
            else if (selectedData == GetData.DataColumn)
            {
                var nts = GenData.GetSchema(tableSelected, connectionString, factoryName);
                var win = new DataWindow();
                win.SetDatagrid(nts);
                win.ShowDialog();
            }
            else if (selectedData == GetData.TableQuery)
            {

            }
        }

        public bool AllTableGetCanExecute(object p)
        {
            bool result = false;

            if (!string.IsNullOrEmpty(TableSelected))
            {
                result = true;
            }

            return result;
        }

        public void WpfGeneratorExecute()
        {
            if (selectedWpf == WpfData.Class)
            {
                StringBuilder sb = GenWpf.GeneralClass(spaceName, tableSelected, connectionString,
                    factoryName, false, true);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
        }

        public bool WpfGeneratorCanExecute(object p)
        {
            bool result = false;

            if (!string.IsNullOrEmpty(TableSelected) && !string.IsNullOrEmpty(SpaceName))
            {
                result = true;
            }

            return result;
        }

        public void AngularGeneratorExecute()
        {
            if (selectedAngular == AngularData.Interface)
            {
                StringBuilder sb = GenAngular.GenInterface(tableSelected, connectionString, factoryName);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
            else if (selectedAngular == AngularData.MatTable)
            {
                StringBuilder sb = GenAngular.GenMatTable(tableSelected, connectionString, factoryName);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
            else if(selectedAngular == AngularData.Component)
            {
                StringBuilder sb = GenAngular.GenComponent(tableSelected, connectionString, factoryName);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
            else if (selectedAngular == AngularData.FormEdit)
            {
                StringBuilder sb = GenAngular.GenFormEdit(tableSelected, connectionString, factoryName);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
            else if (selectedAngular == AngularData.FormComponent)
            {
                StringBuilder sb = GenAngular.GenFormComponent(tableSelected, connectionString, factoryName);

                var win = new TextWindow();
                win.SetRTB(sb.ToString(), "");
                win.ShowDialog();
            }
        }

        public bool AngularGeneratorCanExecute(object p)
        {
            bool result = false;

            if (!string.IsNullOrEmpty(TableSelected))
            {
                result = true;
            }

            return result;
        }

        public void AllTableSaveExecute()
        {
        }

        public bool AllTableSaveCanExecute(object p)
        {
            bool result = false;

            return result;
        }

        public void AllTableExecNonQueryExecute()
        {
        }

        #region Method

        private DataTable QueryAllDT(string tablen, string connectionString, string fact)
        {
            DataTable temp = new DataTable();

            DbProviderFactory factory = DbProviderFactories.GetFactory(fact);
            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                DbCommand cmd = connection.CreateCommand();
                cmd.CommandText = "SELECT * FROM" + " [" + tablen + "]";

                connection.Open();

                DbDataAdapter sda = factory.CreateDataAdapter();
                sda.SelectCommand = cmd;
                sda.Fill(temp);

                connection.Close();
            }
            return temp;
        }
        #endregion

    }
}