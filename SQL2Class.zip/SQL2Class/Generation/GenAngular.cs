using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SQL2Class
{
    public static class GenAngular
    {
        public static StringBuilder GenInterface(string className, string ConnectionString, string Factory)
        {
            List<TableColumn> nts = GenData.GetTableColumn(className, ConnectionString, Factory);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("export interface " + GenInterfaceName(className) + " {");

            foreach (var nt in nts)
            {
                sb.AppendLine(GenInterfaceName(nt.ColumnName) + ": " + GenType(nt.DataType)
                 //+ (nt.AllowDBNull ? "?" : "")
                 + ";");
            }
            sb.AppendLine("}");

            return sb;
        }

        public static StringBuilder GenMatTable(string tableName, string ConnectionString, string Factory)
        {
            List<TableColumn> nts = GenData.GetTableColumn(tableName, ConnectionString, Factory);

            StringBuilder sb = new StringBuilder();

            sb.AppendLine("<h1 id=\"tableLabel\">" + GenClass(tableName) + "</h1>");
            sb.AppendLine("<p>This component demonstrates fetching data from the server.</p>");
            sb.AppendLine("<p *ngIf=\"!" + GenInterfaceName(tableName) + "s\"><em>Loading...</em></p>");
            sb.AppendLine("");
            sb.AppendLine("<div class=\"commands text-right\" *ngIf=\"" + GenInterfaceName(tableName) + "s\">");
            sb.AppendLine("<button type=\"button\"");
            sb.AppendLine("[routerLink]=\"['/" + GenLink(tableName) + "-edit']\"");
            sb.AppendLine("class=\"btn btn-success\">");
            sb.AppendLine("Add a new " + tableName.Replace("_", " "));
            sb.AppendLine("</button>");
            sb.AppendLine("</div>");
            sb.AppendLine("");

            sb.AppendLine("<mat-form-field [hidden]=\"!" + GenInterfaceName(tableName) + "s\">");
            sb.AppendLine("<input matInput (keyup)=\"loadData($event.target.value)\"");
            sb.AppendLine("placeholder=\"Filter by name (or part of it)...\">");
            sb.AppendLine("</mat-form-field>");
            sb.AppendLine("");

            sb.AppendLine("<table mat-table class='mat-elevation-z8' "
            + "[dataSource]=\"" + GenInterfaceName(tableName) + "s\" "
            + "[hidden]=\"!" + GenInterfaceName(tableName) + "s\"");
            sb.AppendLine("matSort (matSortChange)=\"loadData()\"");
            sb.AppendLine("matSortActive=\"{{defaultSortColumn}}\"");
            sb.AppendLine("matSortDirection=\"{{defaultSortOrder}}\">");
            sb.AppendLine("");

            foreach (var nt in nts)
            {
                sb.AppendLine("<ng-container matColumnDef=\"" + GenInterfaceName(nt.ColumnName) + "\">");
                sb.AppendLine("<th mat-header-cell *matHeaderCellDef mat-sort-header>" + GenClass(nt.ColumnName) + "</th>");
                sb.AppendLine("<td mat-cell *matCellDef=\"let " + GenClass(tableName) + "\">"
                    + "{{" + GenClass(tableName) + "." + GenInterfaceName(nt.ColumnName) + "}}</td>");
                sb.AppendLine("</ng-container>");
                sb.AppendLine("");
            }

            sb.AppendLine("<tr mat-header-row *matHeaderRowDef=\"displayedColumns\"></tr>");
            sb.AppendLine("<tr mat-row *matRowDef=\"let row; columns: displayedColumns;\"></tr>");
            sb.AppendLine("</table>");
            sb.AppendLine("");

            sb.AppendLine("<mat-paginator [hidden]=\"!" + GenInterfaceName(tableName) + "s\"");
            sb.AppendLine("(page)=\"getData($event)\"");
            sb.AppendLine("[pageSize]=\"10\"");
            sb.AppendLine("[pageSizeOptions]=\"[10, 20, 50]\"");
            sb.AppendLine("showFirstLastButtons></mat-paginator>");

            return sb;
        }

        public static StringBuilder GenComponent(string tableName, string ConnectionString, string Factory)
        {
            List<TableColumn> nts = GenData.GetTableColumn(tableName, ConnectionString, Factory);

            string keyColumn = GenKeyColumnName(nts);
            string keyType = GenKeyColumnType(nts);

            StringBuilder sb = new StringBuilder();

            sb.AppendLine($"export class {GenClass(tableName)}Component " + "{");
            sb.Append("public displayedColumns: string[] = [");
            sb.Append(string.Join(',', nts.Select(x => "'" + GenInterfaceName(x.ColumnName) + "'")));
            sb.AppendLine("];");
            sb.AppendLine($"public {GenInterfaceName(tableName)}s: MatTableDataSource<{GenClass(tableName)}>;");
            sb.AppendLine("");
            sb.AppendLine("defaultPageIndex: number = 0;");
            sb.AppendLine("defaultPageSize: number = 10;");
            sb.AppendLine($"public defaultSortColumn: string = \"{keyColumn}\";");
            sb.AppendLine("public defaultSortOrder: string = \"asc\";");
            sb.AppendLine("");
            sb.AppendLine($"defaultFilterColumn: string = \"{keyColumn}\";");
            sb.AppendLine("filterQuery: string = null;");
            sb.AppendLine("");
            sb.AppendLine("@ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;");
            sb.AppendLine("@ViewChild(MatSort, { static: false }) sort: MatSort;");
            sb.AppendLine("");
            sb.AppendLine($"constructor(private {GenInterfaceName(tableName)}Service: {GenClass(tableName)}Service) "
                + "{");
            sb.AppendLine("");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("ngOnInit() {");
            sb.AppendLine("this.loadData();");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("loadData(query: string = null) {");
            sb.AppendLine("var pageEvent = new PageEvent();");
            sb.AppendLine("pageEvent.pageIndex = this.defaultPageIndex;");
            sb.AppendLine("pageEvent.pageSize = this.defaultPageSize;");
            sb.AppendLine("if (query) {");
            sb.AppendLine("this.filterQuery = query;");
            sb.AppendLine("}");
            sb.AppendLine("this.getData(pageEvent);");
            sb.AppendLine("}");
            sb.AppendLine("");
            sb.AppendLine("getData(event: PageEvent) {");
            sb.AppendLine("var sortColumn = (this.sort)");
            sb.AppendLine("? this.sort.active");
            sb.AppendLine(": this.defaultSortColumn;");
            sb.AppendLine("");
            sb.AppendLine("var sortOrder = (this.sort)");
            sb.AppendLine("? this.sort.direction");
            sb.AppendLine(": this.defaultSortOrder;");
            sb.AppendLine("");
            sb.AppendLine("var filterColumn = (this.filterQuery)");
            sb.AppendLine("? this.defaultFilterColumn");
            sb.AppendLine(": null;");
            sb.AppendLine("");
            sb.AppendLine("var filterQuery = (this.filterQuery)");
            sb.AppendLine("? this.filterQuery");
            sb.AppendLine(": null;");
            sb.AppendLine($"this.{GenInterfaceName(tableName)}Service.getData<ApiResult<{GenClass(tableName)}>>(");
            sb.AppendLine("event.pageIndex,");
            sb.AppendLine("event.pageSize,");
            sb.AppendLine("sortColumn,");
            sb.AppendLine("sortOrder,");
            sb.AppendLine("filterColumn,");
            sb.AppendLine("filterQuery)");
            sb.AppendLine(".subscribe(result => {");
            sb.AppendLine("this.paginator.length = result.totalCount;");
            sb.AppendLine("this.paginator.pageIndex = result.pageIndex;");
            sb.AppendLine("this.paginator.pageSize = result.pageSize;");
            sb.AppendLine($"this.{GenInterfaceName(tableName)}s = new MatTableDataSource<{GenClass(tableName)}>(result.data);");
            sb.AppendLine("}, error => console.error(error));");
            sb.AppendLine("}");
            sb.AppendLine("}");
            sb.AppendLine("");

            return sb;
        }

        public static StringBuilder GenFormEdit(string tableName, string ConnectionString, string Factory)
        {
            List<TableColumn> nts = GenData.GetTableColumn(tableName, ConnectionString, Factory);

            string keyColumn = GenKeyColumnName(nts);
            string keyType = GenKeyColumnType(nts);

            StringBuilder sb = new StringBuilder();
            sb.AppendLine("<div class=\"" + GenLink(tableName) + "-edit\">");
            sb.AppendLine("<h1>{{title}}</h1>");
            sb.AppendLine($"<p *ngIf=\"this.{keyColumn} && !"
                + GenInterfaceName(tableName) + "\"><em>Loading...</em></p>");
            sb.AppendLine("<div class=\"form\" [formGroup]=\"form\" (ngSubmit)=\"onSubmit()\">");
            sb.AppendLine("");

            // Add Reactive form
            foreach (var nt in nts)
            {
                if (nt.DataType == typeof(DateTime))
                {
                    sb.AppendLine("<mat-form-field appearance=\"fill\">");
                    sb.AppendLine("<mat-label>Choose a date</mat-label>");
                    sb.AppendLine("<input matInput [matDatepicker]=\"picker\" "
                        + "formControlName=\"" + GenInterfaceName(nt.ColumnName) + "\">");
                    sb.AppendLine("<mat-datepicker-toggle matSuffix [for]=\"picker\"></mat-datepicker-toggle>");
                    sb.AppendLine("<mat-datepicker #picker></mat-datepicker>");

                    if (!nt.AllowDBNull)
                    {
                        sb.AppendLine($"<mat-error *ngIf=\"form.get('{GenInterfaceName(keyColumn)}').errors?.required\">");
                        sb.AppendLine("This field is required");
                        sb.AppendLine("</mat-error>");
                    }

                    sb.AppendLine("</mat-form-field>");
                }
                else
                {
                    sb.AppendLine("<div class=\"form-group\">");
                    sb.AppendLine("<label for=\"" + GenInterfaceName(nt.ColumnName) + $"\">{GenClass(nt.ColumnName)}</label>");
                    sb.AppendLine("<br />");
                    sb.AppendLine("<input type=\"text\" id=\"" + GenInterfaceName(nt.ColumnName) + "\"");
                    sb.AppendLine("formControlName=\"" + GenInterfaceName(nt.ColumnName) + "\" required");
                    sb.AppendLine("placeholder=\"" + GenClass(nt.ColumnName) + "\"");
                    sb.AppendLine("class=\"form-control\" />");
                    sb.AppendLine("");
                    sb.AppendLine("<div *ngIf=\"form.get('" + GenInterfaceName(nt.ColumnName) + "').invalid &&");
                    sb.AppendLine("(form.get('" + GenInterfaceName(nt.ColumnName) + "').dirty || "
                        + "form.get('" + GenInterfaceName(nt.ColumnName) + "').touched)\"");
                    sb.AppendLine("class=\"invalid-feedback\">");

                    if (!nt.AllowDBNull)
                    {
                        sb.AppendLine("<div *ngIf=\"form.get('" + GenInterfaceName(nt.ColumnName)
                            + "').errors?.required\">");
                        sb.AppendLine(GenClass(nt.ColumnName) + " required");
                        sb.AppendLine("</div>");
                    }

                    if (nt.DataType == typeof(int) || nt.DataType == typeof(double)
                        || nt.DataType == typeof(float) || nt.DataType == typeof(long)
                        || nt.DataType == typeof(short) || nt.DataType == typeof(byte))
                    {
                        sb.AppendLine("<div *ngIf=\"form.get('" + GenInterfaceName(nt.ColumnName)
                            + "').errors?.pattern\">");
                        sb.AppendLine(GenClass(nt.ColumnName) + " is number.");
                        sb.AppendLine("</div>");
                    }
                    else if (nt.DataType == typeof(string))
                    {
                        sb.AppendLine("<div *ngIf=\"form.get('" + GenInterfaceName(nt.ColumnName)
                            + "').errors?.pattern\">");
                        sb.AppendLine(GenClass(nt.ColumnName) + $" limit to {nt.ColumnSize} characters.");
                        sb.AppendLine("</div>");
                    }
                    sb.AppendLine("</div>");
                    sb.AppendLine("</div>");
                }
                sb.AppendLine("");
            }

            // Add Button
            sb.AppendLine("<div class=\"form-group commands\">");
            sb.AppendLine($"<button *ngIf=\"{keyColumn}\" type=\"submit\"");
            sb.AppendLine("(click)=\"onSubmit()\"");
            sb.AppendLine("[disabled]=\"form.invalid\"");
            sb.AppendLine("class=\"btn btn-success\">");
            sb.AppendLine("Save");
            sb.AppendLine("</button>");

            sb.AppendLine($"<button *ngIf=\"!{keyColumn}\" type=\"submit\"");
            sb.AppendLine("(click)=\"onSubmit()\"");
            sb.AppendLine("[disabled]=\"form.invalid\"");
            sb.AppendLine("class=\"btn btn-success\">");
            sb.AppendLine("Create");
            sb.AppendLine("</button>");

            sb.AppendLine("<button type=\"button\"");
            sb.AppendLine("[routerLink]=\"['/" + GenLink(tableName) + "']\"");
            sb.AppendLine("class=\"btn btn-default\">");
            sb.AppendLine("Cancel");
            sb.AppendLine("</button>");
            sb.AppendLine("</div>");

            // End Form
            sb.AppendLine("</div>");
            sb.AppendLine("</div>");

            return sb;
        }

        public static StringBuilder GenFormComponent(string tableName, string ConnectionString, string Factory)
        {
            List<TableColumn> nts = GenData.GetTableColumn(tableName, ConnectionString, Factory);

            string keyColumn = GenKeyColumnName(nts);
            string keyType = GenKeyColumnType(nts);

            // Component
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("@Component({");
            sb.AppendLine($"selector: 'app-{GenLink(tableName)}-edit',");
            sb.AppendLine($"templateUrl: './{GenLink(tableName)}-edit.component.html',");
            sb.AppendLine($"styleUrls: ['./{GenLink(tableName)}-edit.component.css']");
            sb.AppendLine("})");
            sb.AppendLine("");

            // class
            sb.AppendLine("export class " + GenClass(tableName) + "EditComponent {");
            sb.AppendLine("title: string;");
            sb.AppendLine("form: FormGroup;");
            sb.AppendLine($"{GenInterfaceName(tableName)}: {GenClass(tableName)};");
            sb.AppendLine("");

            // key
            sb.AppendLine($"{keyColumn}?: {keyType};");

            // constructor
            sb.AppendLine("constructor(");
            sb.AppendLine("private fb: FormBuilder,");
            sb.AppendLine("private activedRoute: ActivatedRoute,");
            sb.AppendLine("private router: Router,");
            sb.AppendLine("private " + GenInterfaceName(tableName) + "Service: " + GenClass(tableName) + "Service) {");
            sb.AppendLine("}");
            sb.AppendLine("");

            // ngOnInit
            sb.AppendLine("ngOnInit() {");
            sb.AppendLine("this.form = this.fb.group({");

            // Each column in table
            foreach (var nt in nts)
            {
                sb.AppendLine($"{GenInterfaceName(nt.ColumnName)}: ['',");
                sb.AppendLine("[");

                if (!nt.AllowDBNull)
                {
                    sb.AppendLine("Validators.required,");
                }

                // 
                if (nt.DataType == typeof(int) || nt.DataType == typeof(double)
                        || nt.DataType == typeof(float) || nt.DataType == typeof(long)
                        || nt.DataType == typeof(short) || nt.DataType == typeof(byte))
                {
                    sb.AppendLine("Validators.pattern(\"\\^(0|-*[1-9]+[0-9]*)\\$\")");
                }
                else if (nt.DataType == typeof(string))
                {
                    sb.AppendLine("Validators.pattern(\"\\^[\\\\d\\\\w\\\\W]{1," + nt.ColumnSize + "}\\$\")");
                }

                sb.AppendLine("]],");
            }

            sb.AppendLine("})");
            sb.AppendLine("this.loadData();");
            sb.AppendLine("}");
            sb.AppendLine("");

            // Load data
            sb.AppendLine("loadData() {");

            if (keyType == "number")
            {
                sb.AppendLine($"this.{keyColumn} = +this.activedRoute.snapshot.paramMap.get('{keyColumn}');");
            }
            else
            {
                sb.AppendLine($"this.{keyColumn} = this.activedRoute.snapshot.paramMap.get('{keyColumn}');");
            }


            sb.AppendLine("");
            sb.AppendLine($"if (this.{keyColumn}) " + "{");
            sb.AppendLine($"this.form.get(\"{keyColumn}\").disable();");
            sb.AppendLine($"this.{GenService(tableName)}.get<{GenClass(tableName)}>(this.{keyColumn})");
            sb.AppendLine(".subscribe(result => {");
            sb.AppendLine($"this.{GenInterfaceName(tableName)} = result;");
            sb.AppendLine($"this.title = \"Edit - \" + this.{GenInterfaceName(tableName)}.{keyColumn};");
            sb.AppendLine("// update the form with the weather value");
            sb.AppendLine($"this.form.patchValue(this.{GenInterfaceName(tableName)});");
            sb.AppendLine("}, error => console.error(error));");
            sb.AppendLine("}");
            sb.AppendLine("else {");
            sb.AppendLine($"this.title = \"Create a new {GenClass(tableName)}\";");
            sb.AppendLine("}");
            sb.AppendLine("}");

            // On Submit
            sb.AppendLine("onSubmit() {");
            sb.AppendLine($"var {GenInterfaceName(tableName)} = (this.{keyColumn}) ? "
                + $"this.{GenInterfaceName(tableName)} : <{GenClass(tableName)}>" + "{};");
            sb.AppendLine("");

            // Get value from each form
            foreach (var nt in nts)
            {
                if (nt.AllowDBNull)
                {
                }

                if (nt.DataType == typeof(int) || nt.DataType == typeof(double)
                        || nt.DataType == typeof(float) || nt.DataType == typeof(long)
                        || nt.DataType == typeof(short) || nt.DataType == typeof(byte))
                {
                    sb.AppendLine($"{GenInterfaceName(tableName)}.{GenInterfaceName(nt.ColumnName)} = "
                        + $"+this.form.get(\"{GenInterfaceName(nt.ColumnName)}\").value;");
                }
                else //if (nt.DataType == typeof(string) || nt.DataType == typeof(byte[]))
                {
                    sb.AppendLine($"{GenInterfaceName(tableName)}.{GenInterfaceName(nt.ColumnName)} = "
                        + $"this.form.get(\"{GenInterfaceName(nt.ColumnName)}\").value;");
                }

            }

            // Decide new or edit mode
            sb.AppendLine($"if (this.{keyColumn}) " + "{");
            sb.AppendLine("// EDIT mode");
            sb.AppendLine($"this.{GenService(tableName)}.put<{GenClass(tableName)}>"
                + $"({GenInterfaceName(tableName)})");
            sb.AppendLine(".subscribe(result => {");
            sb.AppendLine("// go back to view");
            sb.AppendLine($"this.router.navigate(['/{GenLink(tableName)}']);");
            sb.AppendLine("}, error => console.error(error));");
            sb.AppendLine("}");
            sb.AppendLine("else {");
            sb.AppendLine("// ADD NEW mode");
            sb.AppendLine($"this.{GenService(tableName)}.post<{GenClass(tableName)}>"
                + $"({GenInterfaceName(tableName)})");
            sb.AppendLine(".subscribe(result => {");
            sb.AppendLine("// go back to view");
            sb.AppendLine($"this.router.navigate(['/{GenLink(tableName)}']);");
            sb.AppendLine("}, error => console.log(error));");
            sb.AppendLine("}");

            sb.AppendLine("}");
            sb.AppendLine("}");

            return sb;
        }

        private static string GenLink(string name)
        {
            return name.ToLower().Replace("_", "-");
        }

        private static string GenType(Type type)
        {
            if (type == typeof(string))
                return "string";
            else if (type == typeof(DateTime))
                return "Date";
            else
                return "number";
        }

        private static string GenInterfaceName(string name)
        {
            if (name.Contains("_"))
            {
                string[] sp = name.Split('_');
                string res = sp[0].ToLower();

                for (int i = 1; i < sp.Length; i++)
                {
                    res += (sp[i][0] + "").ToUpper() + sp[i].Substring(1, sp[i].Length - 1).ToLower();
                }

                return res;
            }
            else
            {
                return (name[0] + "").ToLower() + name.Substring(1, name.Length - 1);
            }
        }

        private static string GenClass(string name)
        {
            if (name.Contains("_"))
            {
                string res = "";
                string[] sp = name.Split('_');

                for (int i = 0; i < sp.Length; i++)
                {
                    res += (sp[i][0] + "").ToUpper() + sp[i].Substring(1, sp[i].Length - 1).ToLower();
                }

                return res;
            }
            else
            {
                return (name[0] + "").ToUpper() + name.Substring(1, name.Length - 1);
            }
        }

        private static string GenService(string name)
        {
            return GenInterfaceName(name) + "Service";
        }

        private static string GenKeyColumnName(List<TableColumn> nts)
        {
            if (nts.Any(x => x.IsAutoIncrement))
            {
                var nt = nts.First(x => x.IsAutoIncrement);
                return GenInterfaceName(nt.ColumnName);
            }

            return "keyName";
        }

        private static string GenKeyColumnType(List<TableColumn> nts)
        {
            if (nts.Any(x => x.IsAutoIncrement))
            {
                var nt = nts.First(x => x.IsAutoIncrement);
                if (nt.DataType == typeof(int) || nt.DataType == typeof(double)
                        || nt.DataType == typeof(float) || nt.DataType == typeof(long)
                        || nt.DataType == typeof(short) || nt.DataType == typeof(byte))
                {
                    return "number";
                }
                else
                {
                    return "string";
                }
            }

            return "keyType";
        }
    }
}