namespace SQL2Class
{
    public enum GetData
    {
        Field,
        DataColumn,
        TableQuery
    }

    public enum WpfData
    {
        Class,
        DataGrid,
        ListView,
        GridAdd
    }

    public enum AngularData
    {
        Interface,
        MatTable,
        Component,
        FormEdit,
        FormComponent,
    }
}