namespace SQL2Class
{
    public class TextViewModel : ViewModelBase
    {
        private readonly TextWindow _window;
        public TextViewModel(TextWindow window)
        {
            _window = window;
        }
    }
}