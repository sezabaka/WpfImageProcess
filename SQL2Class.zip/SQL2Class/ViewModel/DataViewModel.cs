namespace SQL2Class
{
    public class DataViewModel : ViewModelBase
    {
        private readonly DataWindow _window;
        public DataViewModel(DataWindow window)
        {
            _window = window;
        }
    }
}