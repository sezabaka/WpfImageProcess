using System;
using System.ComponentModel;

namespace SQL2Class
{
    public class TableColumn : INotifyPropertyChanged
    {
        private String columnname;
        public String ColumnName
        {
            get { return columnname; }
            set
            {
                columnname = value;
                OnPropertyChanged("ColumnName");
            }
        }

        private int columnordinal;
        public int ColumnOrdinal
        {
            get { return columnordinal; }
            set
            {
                columnordinal = value;
                OnPropertyChanged("ColumnOrdinal");
            }
        }

        private int columnsize;
        public int ColumnSize
        {
            get { return columnsize; }
            set
            {
                columnsize = value;
                OnPropertyChanged("ColumnSize");
            }
        }

        private int numericprecision;
        public int NumericPrecision
        {
            get { return numericprecision; }
            set
            {
                numericprecision = value;
                OnPropertyChanged("NumericPrecision");
            }
        }

        private int numericscale;
        public int NumericScale
        {
            get { return numericscale; }
            set
            {
                numericscale = value;
                OnPropertyChanged("NumericScale");
            }
        }

        private Type datatype;
        public Type DataType
        {
            get { return datatype; }
            set
            {
                datatype = value;
                OnPropertyChanged("DataType");
            }
        }

        private int providertype;
        public int ProviderType
        {
            get { return providertype; }
            set
            {
                providertype = value;
                OnPropertyChanged("ProviderType");
            }
        }

        private string islong;
        public string IsLong
        {
            get { return islong; }
            set
            {
                islong = value;
                OnPropertyChanged("IsLong");
            }
        }

        private bool allowdbnull;
        public bool AllowDBNull
        {
            get { return allowdbnull; }
            set
            {
                allowdbnull = value;
                OnPropertyChanged("AllowDBNull");
            }
        }

        private bool isreadonly;
        public bool IsReadOnly
        {
            get { return isreadonly; }
            set
            {
                isreadonly = value;
                OnPropertyChanged("IsReadOnly");
            }
        }

        private bool isrowversion;
        public bool IsRowVersion
        {
            get { return isrowversion; }
            set
            {
                isrowversion = value;
                OnPropertyChanged("IsRowVersion");
            }
        }

        private string isunique;
        public string IsUnique
        {
            get { return isunique; }
            set
            {
                isunique = value;
                OnPropertyChanged("IsUnique");
            }
        }

        private string iskey;
        public string IsKey
        {
            get { return iskey; }
            set
            {
                iskey = value;
                OnPropertyChanged("IsKey");
            }
        }

        private bool isautoincrement;
        public bool IsAutoIncrement
        {
            get { return isautoincrement; }
            set
            {
                isautoincrement = value;
                OnPropertyChanged("IsAutoIncrement");
            }
        }

        private String baseschemaname;
        public String BaseSchemaName
        {
            get { return baseschemaname; }
            set
            {
                baseschemaname = value;
                OnPropertyChanged("BaseSchemaName");
            }
        }

        private String basecatalogname;
        public String BaseCatalogName
        {
            get { return basecatalogname; }
            set
            {
                basecatalogname = value;
                OnPropertyChanged("BaseCatalogName");
            }
        }

        private String basetablename;
        public String BaseTableName
        {
            get { return basetablename; }
            set
            {
                basetablename = value;
                OnPropertyChanged("BaseTableName");
            }
        }

        private String basecolumnname;
        public String BaseColumnName
        {
            get { return basecolumnname; }
            set
            {
                basecolumnname = value;
                OnPropertyChanged("BaseColumnName");
            }
        }

        public TableColumn(String columnname, int columnordinal, int columnsize,
            int numericprecision, int numericscale, Type datatype,
            int providertype, string islong, bool allowdbnull, bool isreadonly,
            bool isrowversion, string isunique, string iskey, bool isautoincrement,
            String baseschemaname, String basecatalogname, String basetablename,
            String basecolumnname)
        {
            ColumnName = columnname;
            ColumnOrdinal = columnordinal;
            ColumnSize = columnsize;
            NumericPrecision = numericprecision;
            NumericScale = numericscale;
            DataType = datatype;
            ProviderType = providertype;
            IsLong = islong;
            AllowDBNull = allowdbnull;
            IsReadOnly = isreadonly;
            IsRowVersion = isrowversion;
            IsUnique = isunique;
            IsKey = iskey;
            IsAutoIncrement = isautoincrement;
            BaseSchemaName = baseschemaname;
            BaseCatalogName = basecatalogname;
            BaseTableName = basetablename;
            BaseColumnName = basecolumnname;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string s)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(s));
            }
        }
    }
}