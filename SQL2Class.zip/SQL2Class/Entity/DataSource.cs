using System.Collections.Generic;
using System.ComponentModel;

namespace SQL2Class
{
    public class DataSource : INotifyPropertyChanged
    {
        private int id;
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                OnPropertyChanged("Name");
            }
        }

        private string factory;
        public string Factory
        {
            get { return factory; }
            set
            {
                factory = value;
                OnPropertyChanged("Factory");
            }
        }

        public static DataSource Egg(int id, string name, string factory)
        {
            DataSource temp = new DataSource();
            temp.Id = id;
            temp.Name = name;
            temp.Factory = factory;

            return temp;
        }

        public static List<DataSource> GetAll()
        {
            List<DataSource> dss = new List<DataSource>();
            dss.Add(DataSource.Egg(0, "Microsoft Access", "System.Data.OleDb"));
            dss.Add(DataSource.Egg(1, "SQL Server", "System.Data.SqlClient"));
            dss.Add(DataSource.Egg(2, "Microsoft Access 2007", "System.Data.OleDb"));
            dss.Add(DataSource.Egg(3, "MDF File", "System.Data.SqlClient"));
            //dss.Add(DataSource.Egg(4, "SDF File", "System.Data.SqlServerCe.4.0"));
            dss.Add(DataSource.Egg(4, "PostgreSQL", "Npgsql"));
            dss.Add(DataSource.Egg(5, "OracleDB", "Oracle"));


            return dss;
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged(string s)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(s));
            }
        }
    }
}