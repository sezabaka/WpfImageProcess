using System.Collections.Generic;
using System.Data;
using System.Windows;

namespace SQL2Class
{
    public partial class DataWindow : Window
    {
        DataViewModel viewmodel;

        public DataWindow()
        {
            InitializeComponent();
            viewmodel = new DataViewModel(this);
            this.DataContext = viewmodel;
        }

        public void SetDatagrid(List<NT> entity)
        {
            dgAll.ItemsSource = entity;
        }

        public void SetDatagrid(DataTable table)
        {
            dgAll.ItemsSource = table.DefaultView;
        }
    }
}