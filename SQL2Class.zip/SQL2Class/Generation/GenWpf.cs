using System.Collections.Generic;
using System.Text;

namespace SQL2Class
{
    public static class GenWpf
    {
        public static StringBuilder GeneralClass(string nameSpace,
            string className, string ConnectionString, string Factory, bool hasDataError, bool connectDatabase)
        {
            List<NT> nts = GenData.GetField(className, ConnectionString, Factory);

            return GenCommon.GeneralClass(nts, nameSpace, className, hasDataError, connectDatabase);
        }
    }

}