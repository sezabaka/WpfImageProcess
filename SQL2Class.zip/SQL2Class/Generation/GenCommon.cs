using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SQL2Class
{
    public static class GenCommon
    {
        public static StringBuilder GeneralClass(List<NT> nts, string nameSpace,
            string className, bool hasDataError, bool connectDatabase)
        {
            string de = "";
            if (hasDataError)
                de = ", IDataErrorInfo";

            StringBuilder sb = new StringBuilder();
            sb.Append("using System;\r");
            sb.Append("using System.ComponentModel;\r");
            sb.Append("using System.Runtime.Serialization;\r");
            sb.Append("using System.Collections.Generic;\r");
            sb.Append("using System.Linq;\r");
            sb.Append("using System.Collections.ObjectModel;\r");

            if (connectDatabase)
            {
                sb.Append("using System.Data.Linq.Mapping;\r");
                sb.Append("\r");
                sb.Append("namespace " + nameSpace + "\r");
                sb.Append("{\r");
                sb.Append(MakeSpace(1) + "[Serializable]\r");
                sb.Append(MakeSpace(1) + "[DataContract]\r");
                sb.Append(MakeSpace(1) + "[Table(Name = \"" + className + "\")]\r");
            }

            sb.Append(MakeSpace(1) + "public class " + className + " : INotifyPropertyChanged" + de + "\r");
            sb.Append(MakeSpace(1) + "{\r");

            foreach (NT nt in nts)
            {
                sb.Append(MakeSpace(2) + "private " + nt.FieldType.Name + " " + nt.FieldName.ToLower() + ";\r");

                if (connectDatabase)
                {
                    sb.Append(MakeSpace(2) + "[DataMember]\r");

                    if (nt.FieldName == "Id")
                    {
                        sb.Append(MakeSpace(2) + "[Column(Name = \"Id\", IsDbGenerated = true, IsPrimaryKey = true)]\r");
                    }
                    else
                    {
                        sb.Append(MakeSpace(2) + "[Column(Name = \"" + nt.FieldName + "\")]\r");
                    }
                }

                sb.Append(MakeSpace(2) + "public " + nt.FieldType.Name + " " + nt.FieldName + "\r");
                sb.Append(MakeSpace(2) + "{\r");
                sb.Append(MakeSpace(3) + "get { return " + nt.FieldName.ToLower() + "; }\r");
                sb.Append(MakeSpace(3) + "set\r");
                sb.Append(MakeSpace(3) + "{\r");
                sb.Append(MakeSpace(4) + nt.FieldName.ToLower() + " = value;\r");
                sb.Append(MakeSpace(4) + "OnPropertyChanged(\"" + nt.FieldName + "\");\r");
                sb.Append(MakeSpace(3) + "}\r");
                sb.Append(MakeSpace(2) + "}\r");
                sb.Append("\r");
            }

            if (!connectDatabase)
            {
                string st = MakeSpace(2) + "public " + className + "(";

                foreach (NT nt in nts)
                {
                    st += "" + nt.FieldType.Name + " " + nt.FieldName.ToLower() + ",";
                }

                st = st.Remove(st.Length - 1, 1);
                st += ")\r";
                sb.Append(st);
                sb.Append(MakeSpace(2) + "{\r");

                foreach (NT nt in nts)
                {
                    sb.Append(MakeSpace(3) + nt.FieldName + " = " + nt.FieldName.ToLower() + ";\r");
                }
                sb.Append(MakeSpace(2) + "}\r");
            }
            else
            {
                string st = MakeSpace(2) + "public static " + className + " Egg(";

                foreach (NT nt in nts)
                {
                    st += "" + nt.FieldType.Name + " " + nt.FieldName.ToLower() + ",";
                }

                st = st.Remove(st.Length - 1, 1);
                st += ")\r";
                sb.Append(st);
                sb.Append(MakeSpace(2) + "{\r");

                sb.Append(MakeSpace(3) + className + " temp = new " + className + "();\r");

                foreach (NT nt in nts)
                {
                    sb.Append(MakeSpace(3) + "temp." + nt.FieldName + " = " + nt.FieldName.ToLower() + ";\r");
                }

                sb.Append(MakeSpace(3) + "return temp;\r");

                sb.Append(MakeSpace(2) + "}\r");
            }
            sb.Append("\r");

            sb.Append(MakeSpace(2) + "public static List<" + className + "> GetAll" + className + "()\r");
            sb.Append(MakeSpace(2) + "{\r");
            sb.Append(MakeSpace(3) + "using (BaseDemo bd = new BaseDemo())\r");
            sb.Append(MakeSpace(3) + "{\r");
            sb.Append(MakeSpace(4) + "return bd.GetSorted<" + className + ">(\"\").ToList();\r");
            sb.Append(MakeSpace(3) + "}\r");
            sb.Append(MakeSpace(2) + "}\r");

            sb.Append(MakeSpace(2) + "public static ObservableCollection<" + className + "> GetAllOb" + className + "()\r");
            sb.Append(MakeSpace(2) + "{\r");
            sb.Append(MakeSpace(3) + "using (BaseDemo bd = new BaseDemo())\r");
            sb.Append(MakeSpace(3) + "{\r");
            sb.Append(MakeSpace(4) + "return bd.GetSortedOb<" + className + ">(\"\");\r");
            sb.Append(MakeSpace(3) + "}\r");
            sb.Append(MakeSpace(2) + "}\r");

            sb.Append("\r");
            sb.Append(MakeSpace(2) + "public event PropertyChangedEventHandler PropertyChanged;\r");
            sb.Append(MakeSpace(2) + "private void OnPropertyChanged(string s)\r");
            sb.Append(MakeSpace(2) + "{\r");
            sb.Append(MakeSpace(3) + "if (PropertyChanged != null)\r");
            sb.Append(MakeSpace(3) + "{\r");
            sb.Append(MakeSpace(4) + "PropertyChanged(this, new PropertyChangedEventArgs(s));\r");
            sb.Append(MakeSpace(3) + "}\r");
            sb.Append(MakeSpace(2) + "}\r");

            if (hasDataError)
            {
                sb.Append(MakeSpace(2) + "public string this[string columnName]\r");
                sb.Append(MakeSpace(2) + "{\r");
                sb.Append(MakeSpace(3) + "get\r");
                sb.Append(MakeSpace(3) + "{\r");
                sb.Append(MakeSpace(4) + "string result = null;\r");

                foreach (NT nt in nts)
                {
                    sb.Append(MakeSpace(4) + "if (columnName == \"" + nt.FieldName + "\")\r");
                    sb.Append(MakeSpace(4) + "{\r");
                    sb.Append(MakeSpace(5) + "if (string.IsNullOrEmpty(" + nt.FieldName + "))\r");
                    sb.Append(MakeSpace(5) + "{\r");
                    sb.Append(MakeSpace(6) + "result = \"Please enter a " + nt.FieldName + "\";\r");
                    sb.Append(MakeSpace(5) + "}\r");
                    sb.Append(MakeSpace(4) + "}\r");
                }
                sb.Append(MakeSpace(4) + "return result;\r");
                sb.Append(MakeSpace(3) + "}\r");
                sb.Append(MakeSpace(2) + "}\r");
            }

            sb.Append(MakeSpace(1) + "}\r");
            sb.Append("}\r");

            return sb;
        }

        private static string MakeSpace(int level, int qua = 4)
        {
            string result = "";

            for (int i = 0; i < level; i++)
            {
                for (int j = 0; j < qua; j++)
                {
                    result += " ";
                }
            }

            return result;
        }

        public static string GenTableName(string name, string factory)
        {
            if (factory == "Npgsql")
            {
                if (name.Any(c => char.IsUpper(c)))
                {
                    return "\"" + name + "\"";
                }
                else
                {
                    return name;
                }
            }
            else if (factory == "Oracle")
            {
                return name;
            }
            else
            {
                return "[" + name + "]";
            }
        }
    }
}