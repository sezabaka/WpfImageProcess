using System.Collections.Generic;
using System.Data;
using System.Windows;

namespace SQL2Class
{
    public partial class AllTableWindow : Window
    {
        public AllTableWindow(string connectionString, string dataSource)
        {
            this.DataContext = new AllTableViewModel(this, connectionString, dataSource);
            InitializeComponent();
        }
    }
} 