using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace SQL2Class
{
    public static class GenData
    {
        public static List<NT> GetField(string tablen, string connectionString, string fact)
        {
            List<NT> temp = new List<NT>();

            DbProviderFactory factory = DbProviderFactories.GetFactory(fact);
            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                DbCommand cmd = connection.CreateCommand();
                cmd.CommandText = "SELECT * FROM " + GenCommon.GenTableName(tablen, fact);

                connection.Open();

                using (DbDataReader reader = cmd.ExecuteReader(CommandBehavior.SchemaOnly))
                {
                    DataTable table = reader.GetSchemaTable();
                    DataColumn dataType = table.Columns["DataType"];
                    DataColumn columnName = table.Columns["ColumnName"];

                    foreach (DataRow row in table.Rows)
                    {
                        Type type = (Type)row[dataType];
                        temp.Add(new NT(row[columnName].ToString(), type));
                    }

                }
                connection.Close();
            }

            return temp;
        }

        public static DataTable GetSchema(string tablen, string connectionString, string fact)
        {
            DataTable temp = new DataTable();
            DbProviderFactory factory = DbProviderFactories.GetFactory(fact);
            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                DbCommand cmd = connection.CreateCommand();
                cmd.CommandText = "SELECT * FROM " + GenCommon.GenTableName(tablen, fact);

                connection.Open();
                CommandBehavior commandBehavior = CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo;

                using (DbDataReader reader = cmd.ExecuteReader(commandBehavior))
                {
                    temp = reader.GetSchemaTable();
                }
                connection.Close();
            }
            return temp;
        }

        public static List<TableColumn> GetTableColumn(string tablen, string connectionString, string fact)
        {
            List<TableColumn> temp = new List<TableColumn>();

            DbProviderFactory factory = DbProviderFactories.GetFactory(fact);
            using (DbConnection connection = factory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                DbCommand cmd = connection.CreateCommand();
                cmd.CommandText = "SELECT * FROM " + GenCommon.GenTableName(tablen, fact);

                connection.Open();
                CommandBehavior commandBehavior = CommandBehavior.SchemaOnly | CommandBehavior.KeyInfo;

                using (DbDataReader reader = cmd.ExecuteReader(commandBehavior))
                {
                    DataTable table = reader.GetSchemaTable();
                    
                    DataColumn ColumnName = table.Columns["ColumnName"];
                    DataColumn ColumnOrdinal = table.Columns["ColumnOrdinal"];
                    DataColumn ColumnSize = table.Columns["ColumnSize"];
                    DataColumn NumericPrecision = table.Columns["NumericPrecision"];
                    DataColumn NumericScale = table.Columns["NumericScale"];
                    DataColumn DataType = table.Columns["DataType"];
                    DataColumn ProviderType = table.Columns["ProviderType"];
                    DataColumn IsLong = table.Columns["IsLong"];
                    DataColumn AllowDBNull = table.Columns["AllowDBNull"];
                    DataColumn IsReadOnly = table.Columns["IsReadOnly"];
                    DataColumn IsRowVersion = table.Columns["IsRowVersion"];
                    DataColumn IsUnique = table.Columns["IsUnique"];
                    DataColumn IsKey = table.Columns["IsKey"];
                    DataColumn IsAutoIncrement = table.Columns["IsAutoIncrement"];
                    DataColumn BaseSchemaName = table.Columns["BaseSchemaName"];
                    DataColumn BaseCatalogName = table.Columns["BaseCatalogName"];
                    DataColumn BaseTableName = table.Columns["BaseTableName"];
                    DataColumn BaseColumnName = table.Columns["BaseColumnName"];

                    foreach (DataRow row in table.Rows)
                    {
                        bool ad = row[AllowDBNull] == DBNull.Value ? false: (bool)row[AllowDBNull];
                        bool ir = row[IsReadOnly] == DBNull.Value ? false: (bool)row[IsReadOnly];
                        bool iv = row[IsRowVersion] == DBNull.Value ? false: (bool)row[IsRowVersion];
                        bool ia = row[IsAutoIncrement] == DBNull.Value ? false: (bool)row[IsAutoIncrement];

                        temp.Add(new TableColumn(row[ColumnName].ToString(),
                            (int)row[ColumnOrdinal], (int)row[ColumnSize],
                            int.Parse(row[NumericPrecision].ToString()),
                            int.Parse(row[NumericScale].ToString()), (Type)row[DataType],
                            (int)row[ProviderType], row[IsLong].ToString(),
                            ad, ir,
                            iv, row[IsUnique].ToString(),
                            row[IsKey].ToString(), ia,
                            row[BaseSchemaName].ToString(), row[BaseCatalogName].ToString(),
                            row[BaseTableName].ToString(), row[BaseColumnName].ToString()));
                    }

                }
                connection.Close();
            }

            return temp;
        }

    }
}