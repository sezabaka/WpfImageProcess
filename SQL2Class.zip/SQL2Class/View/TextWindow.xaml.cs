using System.Windows;

namespace SQL2Class
{
    public partial class TextWindow : Window
    {
        TextViewModel viewmodel;

        public TextWindow()
        {
            InitializeComponent();
            viewmodel = new TextViewModel(this);
            this.DataContext = viewmodel;
        }

        public void SetRTB(string sb, string helper)
        {
            rtb.AppendText(sb);
            rHelp.AppendText(helper);
            //File.WriteAllText(@"D:\test.cs", sb);
        }
    }
}