﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using CommandLine;

namespace VscHelper
{
    class Program
    {
        static void Main(string[] args)
        {
            Parser.Default.ParseArguments<Program.Options>(args)
                .WithParsed(new Action<Program.Options>(Program.RunOptions))
                .WithNotParsed(new Action<IEnumerable<Error>>(Program.HandleParseError));
        }

        private static void HandleParseError(IEnumerable<Error> errs)
        {
        }

        private static readonly string _class = "class.txt";

        private static readonly string _interface = "interface.txt";

        private static readonly string _service = "service.txt";

        private static readonly string _usercontrol = "usercontrol.txt";
        private static readonly string _usercontrolcs = "usercs.txt";
        private static readonly string _viewmodel = "viewmodel.txt";

        private class Options
        {
            [Option('o', "output", Required = true, HelpText = "Input files to be processed.")]
            public string FileName { get; set; }

            [Option('k', "kind", Required = true, HelpText = "Prints all messages to standard output.")]
            public string Kind { get; set; }
        }

        private static void WriteFile(string name, List<Tuple<string, string>> replaceTexts, string output)
        {
            Assembly assembly = Assembly.GetExecutingAssembly();
            string resourceName = name;
            List<string> rs = assembly.GetManifestResourceNames().ToList<string>();
            string st = rs.FirstOrDefault((string x) => x.Contains(resourceName));
            using (Stream stream = assembly.GetManifestResourceStream(st))
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    using (StreamWriter writer = new StreamWriter(output))
                    {
                        while (!reader.EndOfStream)
                        {
                            string template = reader.ReadLine();
                            foreach (Tuple<string, string> item in replaceTexts)
                            {
                                template = template.Replace(item.Item1, item.Item2);
                            }
                            writer.WriteLine(template);
                        }
                    }
                }
            }
        }

        private static List<string> GetProjectName(out bool multiProject)
        {
            multiProject = false;
            string[] currentPath = Directory.GetCurrentDirectory().Split('\\', StringSplitOptions.None);
            int i = currentPath.Length - 1;
            int i2;
            for (i = currentPath.Length - 1; i >= 1; i = i2 - 1)
            {
                string path = currentPath[0];
                for (int j = 1; j <= i; j++)
                {
                    path = path + "\\" + currentPath[j];
                }
                List<string> allFiles = Directory.GetFiles(path).ToList<string>();
                bool flag = allFiles.Any((string x) => x.Contains(".csproj"));
                if (flag)
                {
                    bool flag2 = allFiles.Count((string x) => x.Contains(".csproj")) > 1;
                    if (flag2)
                    {
                        multiProject = true;
                    }
                    break;
                }
                i2 = i;
            }
            return currentPath.Where((string x, int z) => z >= i).ToList<string>();
        }

        private static void RunOptions(Program.Options opts)
        {
            List<Tuple<string, string>> replaceTexts = new List<Tuple<string, string>>();
            bool manyProject;
            List<string> list = Program.GetProjectName(out manyProject);
            bool flag = list != null;
            if (flag)
            {
                bool flag2 = !manyProject;
                if (flag2)
                {
                    replaceTexts.Add(new Tuple<string, string>("%replaceNamespace%", string.Join(".", list)));
                    switch (opts.Kind)
                    {
                        case "Class":
                            replaceTexts.Add(new Tuple<string, string>("%replaceClass%", opts.FileName));
                            Program.WriteFile(Program._class, replaceTexts, opts.FileName + ".cs");
                            break;
                        case "Interface":
                            replaceTexts.Add(new Tuple<string, string>("%replaceInterface%", opts.FileName));
                            Program.WriteFile(Program._interface, replaceTexts, opts.FileName + ".cs");
                            break;
                        case "Service":
                            replaceTexts.Add(new Tuple<string, string>("%replaceInterface%", "I" + opts.FileName));
                            replaceTexts.Add(new Tuple<string, string>("%replaceService%", opts.FileName));
                            Program.WriteFile(Program._service, replaceTexts, opts.FileName + ".cs");
                            Program.WriteFile(Program._interface, replaceTexts, "Interface\\I" + opts.FileName + ".cs");
                            break;
                        case "UserControl":
                            replaceTexts.Add(new Tuple<string, string>("%replaceClass%", opts.FileName));
                            Program.WriteFile(Program._usercontrol, replaceTexts, opts.FileName + ".xaml");
                            Program.WriteFile(Program._usercontrolcs, replaceTexts, opts.FileName + ".xaml.cs");
                            break;
                        case "ViewModel":
                            replaceTexts.Add(new Tuple<string, string>("%replaceClass%", opts.FileName));
                            Program.WriteFile(Program._viewmodel, replaceTexts, opts.FileName + ".cs");
                            break;
                    }
                }
            }
        }


    }
}
